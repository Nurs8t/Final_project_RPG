package com.chronoshatter.map;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;

public class GameMap {
    public static final int TILE_W = 32;
    public static final int TILE_H = 32;

    private TiledMap map;
    private OrthogonalTiledMapRenderer renderer;
    private int mapPixelW, mapPixelH;

    public GameMap(int level) {
        String path = "maps/level" + level + ".tmx";
        try {
            map = new TmxMapLoader().load(path);
            renderer = new OrthogonalTiledMapRenderer(map);

            // Берём размер из первого тайлового слоя
            for (MapLayer layer : map.getLayers()) {
                if (layer instanceof TiledMapTileLayer) {
                    TiledMapTileLayer tl = (TiledMapTileLayer) layer;
                    mapPixelW = (int)(tl.getWidth()  * tl.getTileWidth());
                    mapPixelH = (int)(tl.getHeight() * tl.getTileHeight());
                    break;
                }
            }
            if (mapPixelW == 0) { mapPixelW = 1280; mapPixelH = 736; }
        } catch (Exception e) {
            mapPixelW = 1280;
            mapPixelH = 736;
        }
    }

    /**
     * Проверяет коллизию с учётом свойства "collider" на слоях.
     * Слои с collider=true (или имя содержит "wall"/"collision") — твёрдые.
     * Слои с collider=false — пропускаются.
     */
    public boolean isSolid(float worldX, float worldY) {
        if (map == null) return false;

        for (MapLayer layer : map.getLayers()) {
            if (!(layer instanceof TiledMapTileLayer)) continue;
            TiledMapTileLayer tl = (TiledMapTileLayer) layer;

            // Читаем свойство "collider" из Tiled
            Object colProp = layer.getProperties().get("collider");

            if (colProp instanceof Boolean) {
                if (!(Boolean) colProp) continue; // collider=false → пропускаем
                // collider=true → проверяем
            } else {
                // Нет свойства — проверяем по имени слоя
                String name = layer.getName().toLowerCase();
                boolean isWallLayer = name.equals("walls") || name.equals("wall")
                    || name.equals("collision") || name.startsWith("walls ");
                if (!isWallLayer) continue;
            }

            int tx = (int)(worldX / tl.getTileWidth());
            int ty = (int)(worldY / tl.getTileHeight());
            TiledMapTileLayer.Cell cell = tl.getCell(tx, ty);
            if (cell != null && cell.getTile() != null) return true;
        }
        return false;
    }

    public boolean isSolidRect(float x, float y, float w, float h) {
        return isSolid(x,     y)
            || isSolid(x+w-1, y)
            || isSolid(x,     y+h-1)
            || isSolid(x+w-1, y+h-1);
    }

    public void render(OrthographicCamera camera) {
        if (renderer == null) return;
        renderer.setView(camera);
        renderer.render();
    }

    public void renderFallback(ShapeRenderer sr) {
        if (map != null) return;
        sr.setColor(new Color(0.15f, 0.15f, 0.2f, 1f));
        sr.rect(0, 0, mapPixelW, mapPixelH);
    }

    public int getPixelWidth()  { return mapPixelW; }
    public int getPixelHeight() { return mapPixelH; }

    public void dispose() {
        if (map != null) map.dispose();
    }
}
