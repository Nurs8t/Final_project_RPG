package com.chronoshatter.utils;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;

public class SoundManager {
    private Sound shoot, hit, death, coin, buy, win, lose;

    public SoundManager() {
        shoot = load("sounds/shoot.wav");
        hit   = load("sounds/hit.wav");
        death = load("sounds/zombie_death.wav");
        coin  = load("sounds/coin_pickup.wav");
        buy   = load("sounds/buy.wav");
        win   = load("sounds/win.wav");
        lose  = load("sounds/lose.wav");
    }

    private Sound load(String path) {
        try { return Gdx.audio.newSound(Gdx.files.internal(path)); }
        catch (Exception e) { return null; }
    }

    private void play(Sound s) {
        if (Assets.soundEnabled && s != null) s.play(0.8f);
    }

    public void playShoot() { play(shoot); }
    public void playHit()   { play(hit); }
    public void playDeath() { play(death); }
    public void playCoin()  { play(coin); }
    public void playBuy()   { play(buy); }
    public void playWin()   { play(win); }
    public void playLose()  { play(lose); }

    public void dispose() {
        Sound[] all = {shoot, hit, death, coin, buy, win, lose};
        for (Sound s : all) if (s != null) s.dispose();
    }
}
